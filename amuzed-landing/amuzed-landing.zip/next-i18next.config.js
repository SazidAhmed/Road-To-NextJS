module.exports = {
    // debug: true,
    i18n: {
        defaultLocale: 'en',
        locales: ['en', 'de', 'fr'],
    },
}