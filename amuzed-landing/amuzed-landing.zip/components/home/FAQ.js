// components/Faq.js

export const Faq = () => {

    useEffect(() => {}, []);

    return (
        <ul className="faq__list">
            <li className="faq__item">
            <details>
                <summary>Why should i buy the booster packs?</summary>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                </details> 
            </li>
        </ul>
    )
}