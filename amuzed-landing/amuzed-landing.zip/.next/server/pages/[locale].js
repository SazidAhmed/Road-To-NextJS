(() => {
var exports = {};
exports.id = 513;
exports.ids = [513];
exports.modules = {

/***/ 168:
/***/ ((module) => {

// Exports
module.exports = {
	"header": "Header_header__VYZ3G",
	"header__container": "Header_header__container__2qn_4"
};


/***/ }),

/***/ 1288:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "Home_container__bCOhY",
	"main": "Home_main__nLjiQ",
	"footer": "Home_footer____T7K",
	"title": "Home_title__T09hD",
	"description": "Home_description__41Owk",
	"code": "Home_code__suPER",
	"grid": "Home_grid__GxQ85",
	"card": "Home_card___LpL1",
	"logo": "Home_logo__27_tb"
};


/***/ }),

/***/ 3193:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$": () => (/* binding */ Footer)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _LanguageSwitchLink__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(210);
/* harmony import */ var _next_i18next_config__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3273);
/* harmony import */ var _next_i18next_config__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_next_i18next_config__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_LanguageSwitchLink__WEBPACK_IMPORTED_MODULE_3__]);
_LanguageSwitchLink__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
// components/Footer.js





// images

const Footer = ()=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const { t  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_1__.useTranslation)("footer");
    const currentLocale = router.query.locale || (_next_i18next_config__WEBPACK_IMPORTED_MODULE_4___default().i18n.defaultLocale);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("footer", {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "social__wrapper--mobile",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_5___default()), {
                        src: "/svgs/twitter-logo.svg",
                        height: "25px",
                        width: "25px",
                        alt: ""
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_5___default()), {
                        src: "/svgs/instagram-logo.svg",
                        height: "25px",
                        width: "25px",
                        alt: ""
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "footer__wrapper",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "footer__title-wrapper",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_5___default()), {
                                src: "/svgs/header-logo.svg",
                                height: "45px",
                                width: "45px",
                                alt: ""
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "footer__title",
                                children: "Amuzed"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "social__wrapper",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_5___default()), {
                                src: "/svgs/twitter-logo.svg",
                                height: "25px",
                                width: "25px",
                                alt: ""
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_5___default()), {
                                src: "/svgs/instagram-logo.svg",
                                height: "25px",
                                width: "25px",
                                alt: ""
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "copyright__wrapper",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: "copyright",
                            children: "AMUZED \xa9 2022 All Rights Reserved."
                        })
                    })
                ]
            })
        ]
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7673:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "h": () => (/* binding */ Header)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _LanguageSwitchLink__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(210);
/* harmony import */ var _next_i18next_config__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3273);
/* harmony import */ var _next_i18next_config__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_next_i18next_config__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _styles_Header_module_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(168);
/* harmony import */ var _styles_Header_module_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_styles_Header_module_css__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_LanguageSwitchLink__WEBPACK_IMPORTED_MODULE_3__]);
_LanguageSwitchLink__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
// components/Footer.js





// assets

// styles

const Header = ()=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
    const { t  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_2__.useTranslation)("header");
    const currentLocale = router.query.locale || (_next_i18next_config__WEBPACK_IMPORTED_MODULE_4___default().i18n.defaultLocale);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("header", {
        className: `${(_styles_Header_module_css__WEBPACK_IMPORTED_MODULE_6___default().header)} ${(_styles_Header_module_css__WEBPACK_IMPORTED_MODULE_6___default().header__container)}`,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_5___default()), {
                src: "/svgs/header-logo.svg",
                alt: "me",
                width: "45",
                height: "45"
            }),
            _next_i18next_config__WEBPACK_IMPORTED_MODULE_4___default().i18n.locales.map((locale)=>{
                if (locale === currentLocale) return null;
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_LanguageSwitchLink__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    locale: locale
                }, locale);
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                className: "button header__button",
                children: "Buy now"
            })
        ]
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 210:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lib_languageDetector__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(556);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_lib_languageDetector__WEBPACK_IMPORTED_MODULE_1__]);
_lib_languageDetector__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
// components/LanguageSwitchLink.js




const LanguageSwitchLink = ({ locale , ...rest })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    let href = rest.href || router.asPath;
    let pName = router.pathname;
    Object.keys(router.query).forEach((k)=>{
        if (k === "locale") {
            pName = pName.replace(`[${k}]`, locale);
            return;
        }
        pName = pName.replace(`[${k}]`, router.query[k]);
    });
    if (locale) {
        href = rest.href ? `/${locale}${rest.href}` : pName;
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
        href: href,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
            onClick: ()=>_lib_languageDetector__WEBPACK_IMPORTED_MODULE_1__/* ["default"].cache */ .Z.cache(locale),
            style: {
                fontSize: "small"
            },
            children: locale
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LanguageSwitchLink);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4373:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);




const LinkComponent = ({ children , skipLocaleHandling , ...rest })=>{
    const router = useRouter();
    const locale = rest.locale || router.query.locale || "";
    let href = rest.href || router.asPath;
    if (href.indexOf("http") === 0) skipLocaleHandling = true;
    if (locale && !skipLocaleHandling) {
        href = href ? `/${locale}${href}` : router.pathname.replace("[locale]", locale);
    }
    return /*#__PURE__*/ _jsx(_Fragment, {
        children: /*#__PURE__*/ _jsx(Link, {
            href: href,
            children: /*#__PURE__*/ _jsx("a", {
                ...rest,
                children: children
            })
        })
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (LinkComponent)));


/***/ }),

/***/ 4102:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "r": () => (/* binding */ BoosterPacksList)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: external "react-parallax-tilt"
const external_react_parallax_tilt_namespaceObject = require("react-parallax-tilt");
var external_react_parallax_tilt_default = /*#__PURE__*/__webpack_require__.n(external_react_parallax_tilt_namespaceObject);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./components/home/BoosterPacksList.js


// animations

// assets

const BoosterPacksList = ()=>{
    const cardsInit = [
        {
            front: "/images/card-1.png",
            back: "/images/card-1--back.png",
            getYours: "/images/get-yours-1.png",
            isFlipped: false,
            isBeingFlipped: false
        },
        {
            front: "/images/card-2.png",
            back: "/images/card-2--back.png",
            getYours: "/images/get-yours-2.png",
            isFlipped: false,
            isBeingFlipped: false
        },
        {
            front: "/images/card-3.png",
            back: "/images/card-3--back.png",
            getYours: "/images/get-yours-3.png",
            isFlipped: false,
            isBeingFlipped: false
        },
        {
            "front": "/images/card-4.png",
            "back": "/images/card-4--back.png",
            "getYours": "/images/get-yours-4.png",
            isFlipped: false,
            isBeingFlipped: false
        }, 
    ];
    const { 0: cards , 1: setCards  } = (0,external_react_.useState)(cardsInit);
    function handleFlip(value, index) {
        let newCards = [
            ...cards
        ];
        newCards[index].isFlipped = value;
        if (!newCards[index].isBeingFlipped) {
            newCards[index].isBeingFlipped = true;
            setCards(newCards);
            setTimeout(()=>{
                newCards[index].isBeingFlipped = false;
                setCards(newCards);
            }, 250);
        }
    }
    return /*#__PURE__*/ jsx_runtime_.jsx("ul", {
        className: "booster-packs__list",
        children: cards && cards.map((card, index)=>{
            return /*#__PURE__*/ jsx_runtime_.jsx("li", {
                className: "booster-packs__item",
                children: /*#__PURE__*/ jsx_runtime_.jsx((external_react_parallax_tilt_default()), {
                    flipHorizontally: card.isFlipped,
                    transitionSpeed: 1250,
                    onEnter: (ev)=>{
                        handleFlip(true, index);
                    },
                    onLeave: (ev)=>{
                        handleFlip(false, index);
                    },
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "packs-item__inner",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: card.isFlipped ? "packs-item__front is-hidden" : "packs-item__front",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: card.front,
                                    height: "100%",
                                    width: "100%",
                                    alt: "",
                                    layout: "responsive",
                                    objectFit: "contain"
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: card.isFlipped ? "packs-item__back is-flipped" : "packs-item__back",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: card.back,
                                        height: "100%",
                                        width: "100%",
                                        alt: "",
                                        layout: "responsive",
                                        objectFit: "contain"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "#",
                                        className: "packs-item__get-yours",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: card.getYours,
                                            height: "100%",
                                            width: "100%",
                                            alt: "",
                                            layout: "responsive",
                                            objectFit: "contain"
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                })
            }, index);
        })
    });
};


/***/ }),

/***/ 2883:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "A": () => (/* binding */ LatestNews)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: external "@glidejs/glide"
const glide_namespaceObject = require("@glidejs/glide");
var glide_default = /*#__PURE__*/__webpack_require__.n(glide_namespaceObject);
;// CONCATENATED MODULE: ./components/home/LatestNews.js


// assets

// slider


const LatestNews = ()=>{
    const news = [
        {
            title: "EmiXem Says Rapping About Mental Health, Addiction Struggles Has Been ‘Therapeutic’",
            date: "01/05/2022",
            imageURL: "/images/emixem-1.png",
            tags: [
                "Trending"
            ]
        },
        {
            title: "Five Reasons Why BeZonYe’s Return to a Traditional Roll-out",
            date: "14/05/2022",
            imageURL: "/images/five-reasons-1.png",
            tags: [
                "Release Radar",
                "NFT"
            ]
        },
        {
            title: "Jid Tudi Announces Dates For 2022 ‘To the Moon’ World Tour",
            date: "04/04/2022",
            imageURL: "/images/jid-tudi-1.png",
            tags: [
                "Trending",
                "Release Radar"
            ]
        }
    ];
    (0,external_react_.useEffect)(()=>{
        // slider
        new (glide_default())(".glide", {
            type: "slider",
            startAt: 0,
            perView: 3,
            gap: 20,
            breakpoints: {
                600: {
                    perView: 1,
                    gap: 0,
                    peek: {
                        before: 0,
                        after: 0
                    }
                },
                991: {
                    perView: 2,
                    gap: 10
                }
            }
        }).mount();
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "glide",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "glide__track",
                "data-glide-el": "track",
                children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                    className: "glide__slides",
                    children: news && news.map((item, index)=>{
                        return /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: "latest-news__item glide__slide",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "latest-news__item-wrapper",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        className: "latest-news__image",
                                        src: item.imageURL,
                                        width: "192",
                                        height: "116",
                                        alt: ""
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "latest-news__title",
                                        children: item.title
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "latest-news__date",
                                        children: item.date
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                        className: "latest-news__tags",
                                        children: item.tags && item.tags.map((tag, index)=>{
                                            return /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "latest-news__tag",
                                                children: tag
                                            }, index);
                                        })
                                    })
                                ]
                            })
                        }, index);
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "glide__bullets",
                "data-glide-el": "controls[nav]",
                children: news && news.map((item, index)=>{
                    return /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        className: "glide__bullet",
                        "data-glide-dir": `=${index}`
                    }, index);
                })
            })
        ]
    });
};


/***/ }),

/***/ 1382:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "G": () => (/* binding */ SliderArtistsSlick)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: external "react-slick"
const external_react_slick_namespaceObject = require("react-slick");
var external_react_slick_default = /*#__PURE__*/__webpack_require__.n(external_react_slick_namespaceObject);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./components/home/SliderArtistsSlick.js
// components/SliderArtists.js


// assets

const SliderArtistsSlick = ()=>{
    var settings = {
        centerMode: true,
        infinite: true,
        centerPadding: 0,
        autoplay: true,
        pauseOnHover: false,
        speed: 500,
        slidesToShow: 7,
        slidesToScroll: 1,
        responsive: [
            {
                breakpoint: 1359,
                settings: {
                    slidesToShow: 5
                }
            },
            {
                breakpoint: 600,
                settings: {
                    slidesToShow: 3
                }
            },
            {
                breakpoint: 430,
                settings: {
                    slidesToShow: 3,
                    centerPadding: 0
                }
            }
        ]
    };
    const artists = [
        "/images/artists/1-celo-abdi_glass.png",
        "/images/artists/2-kool-savas_gold.png",
        "/images/artists/3-alrima_platinum.png",
        "/images/artists/4-rk_diamond.png",
        "/images/artists/5-haft_glass.png",
        "/images/artists/6-bmj_gold.png",
        "/images/artists/7-niaks_platinum.png",
        "/images/artists/8-takt32_diamond.png",
        "/images/artists/9-shotas_glass.png",
        "/images/artists/10-olexesh_gold.png",
        "/images/artists/11-bolemvn_platinum.png",
        "/images/artists/12-larry_diamond.png",
        "/images/artists/13-koba-lad_gold.png",
        "/images/artists/14-pajel_platinum.png",
        "/images/artists/15-liz_diamond.png", 
    ];
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx((external_react_slick_default()), {
            ...settings,
            children: artists && artists.map((artist, index)=>{
                return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "slider-item__wrapper",
                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: artist,
                        width: "500px",
                        height: "895px",
                        alt: ""
                    })
                }, index);
            })
        })
    });
};


/***/ }),

/***/ 7080:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useWindowDimensions)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

function getWindowDimensions() {
    if (false) {}
    return false;
}
function useWindowDimensions() {
    const { 0: windowDimensions , 1: setWindowDimensions  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(getWindowDimensions());
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        if (false) {}
    }, []);
    return windowDimensions;
};


/***/ }),

/***/ 9803:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Fe": () => (/* binding */ getStaticPaths),
  "pc": () => (/* binding */ makeStaticProps)
});

// UNUSED EXPORTS: getI18nPaths, getI18nProps

;// CONCATENATED MODULE: external "next-i18next/serverSideTranslations"
const serverSideTranslations_namespaceObject = require("next-i18next/serverSideTranslations");
// EXTERNAL MODULE: ./next-i18next.config.js
var next_i18next_config = __webpack_require__(3273);
var next_i18next_config_default = /*#__PURE__*/__webpack_require__.n(next_i18next_config);
;// CONCATENATED MODULE: ./lib/getStatic.js


const getI18nPaths = ()=>next_i18next_config_default().i18n.locales.map((lng)=>({
            params: {
                locale: lng
            }
        }));
const getStaticPaths = ()=>({
        fallback: false,
        paths: getI18nPaths()
    });
async function getI18nProps(ctx, ns = [
    "common"
]) {
    const locale = ctx?.params?.locale;
    let props = {
        ...await (0,serverSideTranslations_namespaceObject.serverSideTranslations)(locale, ns)
    };
    return props;
}
function makeStaticProps(ns = {}) {
    return async function getStaticProps(ctx) {
        return {
            props: await getI18nProps(ctx, ns)
        };
    };
}


/***/ }),

/***/ 556:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_language_detector__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3707);
/* harmony import */ var _next_i18next_config_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3273);
/* harmony import */ var _next_i18next_config_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_next_i18next_config_js__WEBPACK_IMPORTED_MODULE_1__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([next_language_detector__WEBPACK_IMPORTED_MODULE_0__]);
next_language_detector__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,next_language_detector__WEBPACK_IMPORTED_MODULE_0__["default"])({
    supportedLngs: (_next_i18next_config_js__WEBPACK_IMPORTED_MODULE_1___default().i18n.locales),
    fallbackLng: (_next_i18next_config_js__WEBPACK_IMPORTED_MODULE_1___default().i18n.defaultLocale)
}));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3273:
/***/ ((module) => {

"use strict";

module.exports = {
    // debug: true,
    i18n: {
        defaultLocale: "en",
        locales: [
            "en",
            "de",
            "fr"
        ]
    }
};


/***/ }),

/***/ 8869:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Home),
/* harmony export */   "getStaticPaths": () => (/* reexport safe */ _lib_getStatic__WEBPACK_IMPORTED_MODULE_2__.Fe),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _lib_getStatic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9803);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var gsap_dist_gsap__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8472);
/* harmony import */ var gsap_dist_gsap__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(gsap_dist_gsap__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var gsap_dist_ScrollTrigger__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4965);
/* harmony import */ var gsap_dist_ScrollTrigger__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(gsap_dist_ScrollTrigger__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var gsap_dist_DrawSVGPlugin__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9258);
/* harmony import */ var gsap_dist_DrawSVGPlugin__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(gsap_dist_DrawSVGPlugin__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _styles_Home_module_css__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(1288);
/* harmony import */ var _styles_Home_module_css__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _components_Link__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4373);
/* harmony import */ var _components_home_SliderArtistsSlick__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1382);
/* harmony import */ var _components_Footer__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3193);
/* harmony import */ var _components_Header__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7673);
/* harmony import */ var _components_home_BoosterPacksList__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(4102);
/* harmony import */ var _components_home_LatestNews__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(2883);
/* harmony import */ var _hooks_useWindowDimensions__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(7080);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_15__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Footer__WEBPACK_IMPORTED_MODULE_10__, _components_Header__WEBPACK_IMPORTED_MODULE_11__]);
([_components_Footer__WEBPACK_IMPORTED_MODULE_10__, _components_Header__WEBPACK_IMPORTED_MODULE_11__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





// animations



// styles

// components

// import { SliderArtists } from '../../components/home/SliderArtists';





// hooks

// assets

function Home() {
    const { t  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_1__.useTranslation)([
        "common",
        "home",
        "footer"
    ]);
    const journeyWrapperRef = (0,react__WEBPACK_IMPORTED_MODULE_4__.useRef)();
    const journeyRef = (0,react__WEBPACK_IMPORTED_MODULE_4__.useRef)();
    const containerRef = (0,react__WEBPACK_IMPORTED_MODULE_4__.useRef)();
    const collectTitleRef = (0,react__WEBPACK_IMPORTED_MODULE_4__.useRef)();
    const { width  } = (0,_hooks_useWindowDimensions__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z)();
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        // animations
        if (width < 991) {
            // journey mobile animation
            gsap_dist_gsap__WEBPACK_IMPORTED_MODULE_5__.gsap.registerPlugin(gsap_dist_ScrollTrigger__WEBPACK_IMPORTED_MODULE_6__.ScrollTrigger, gsap_dist_DrawSVGPlugin__WEBPACK_IMPORTED_MODULE_7__.DrawSVGPlugin);
            // svgs
            gsap_dist_gsap__WEBPACK_IMPORTED_MODULE_5__.gsap.set(".journey-polyline--mobile", {
                drawSVG: "0%",
                autoAlpha: 1
            });
            gsap_dist_gsap__WEBPACK_IMPORTED_MODULE_5__.gsap.set(".journey-svg-mobile__circle--1", {
                opacity: 0
            });
            gsap_dist_gsap__WEBPACK_IMPORTED_MODULE_5__.gsap.set(".journey-svg-mobile__circle-outer--1", {
                opacity: 0
            });
            gsap_dist_gsap__WEBPACK_IMPORTED_MODULE_5__.gsap.set(".journey-svg-mobile__circle-outer-dashed--1", {
                opacity: 0,
                transformOrigin: "50% 50%"
            });
            gsap_dist_gsap__WEBPACK_IMPORTED_MODULE_5__.gsap.set(".journey-svg-mobile__circle--2", {
                opacity: 0
            });
            gsap_dist_gsap__WEBPACK_IMPORTED_MODULE_5__.gsap.set(".journey-svg-mobile__circle-outer--2", {
                opacity: 0
            });
            gsap_dist_gsap__WEBPACK_IMPORTED_MODULE_5__.gsap.set(".journey-svg-mobile__circle-outer-dashed--2", {
                opacity: 0,
                transformOrigin: "50% 50%"
            });
            gsap_dist_gsap__WEBPACK_IMPORTED_MODULE_5__.gsap.set(".journey-svg-mobile__circle--3", {
                opacity: 0
            });
            gsap_dist_gsap__WEBPACK_IMPORTED_MODULE_5__.gsap.set(".journey-svg-mobile__circle-outer--3", {
                opacity: 0
            });
            gsap_dist_gsap__WEBPACK_IMPORTED_MODULE_5__.gsap.set(".journey-svg-mobile__circle-outer-dashed--3", {
                opacity: 0,
                transformOrigin: "50% 50%"
            });
            // sections
            gsap_dist_gsap__WEBPACK_IMPORTED_MODULE_5__.gsap.set(".play-to-earn", {
                opacity: 0
            });
            gsap_dist_gsap__WEBPACK_IMPORTED_MODULE_5__.gsap.set(".trade", {
                opacity: 0
            });
            // draw svg desktop animation
            var journeyPolylineMobile = gsap_dist_gsap__WEBPACK_IMPORTED_MODULE_5__.gsap.timeline({
                scrollTrigger: {
                    trigger: ".journey-polyline--mobile",
                    start: "top 40%",
                    endTrigger: ".booster-packs",
                    end: "+=400",
                    scrub: 1
                }
            }).addLabel("one").to(".journey-svg-mobile__circle--1", {
                opacity: 1,
                duration: 1.25
            }, "one").to(".journey-svg-mobile__circle-outer--1", {
                opacity: 1,
                duration: 1
            }, "one").to(".journey-svg-mobile__circle-outer-dashed--1", {
                opacity: 1,
                rotation: 90,
                duration: 1.5
            }, "one").to(".journey-polyline--mobile", {
                drawSVG: "35%",
                duration: 1
            }, "one").to(".play-to-earn", {
                opacity: 1,
                duration: 2
            }, "one").addLabel("two").to(".journey-svg-mobile__circle--2", {
                opacity: 1,
                duration: .25
            }, "two").to(".journey-svg-mobile__circle-outer--2", {
                opacity: 1,
                duration: .25
            }, "two").to(".journey-svg-mobile__circle-outer-dashed--2", {
                opacity: 1,
                rotation: 90,
                duration: 1.5
            }, "two").to(".journey-polyline--mobile", {
                drawSVG: "55%"
            }, "two").addLabel("three").to(".trade", {
                opacity: 1,
                duration: 2
            }, "three").to(".journey-polyline--mobile", {
                drawSVG: "100%",
                duration: 2
            }, "three").to(".journey-svg-mobile__circle--3", {
                opacity: 1,
                duration: 3
            }, "three").to(".journey-svg-mobile__circle-outer--3", {
                opacity: 1,
                duration: 3
            }, "three").to(".journey-svg-mobile__circle-outer-dashed--3", {
                opacity: 1,
                rotation: 90,
                duration: 4
            }, "three");
        } else {
            gsap_dist_gsap__WEBPACK_IMPORTED_MODULE_5__.gsap.registerPlugin(gsap_dist_ScrollTrigger__WEBPACK_IMPORTED_MODULE_6__.ScrollTrigger, gsap_dist_DrawSVGPlugin__WEBPACK_IMPORTED_MODULE_7__.DrawSVGPlugin);
            const sections = gsap_dist_gsap__WEBPACK_IMPORTED_MODULE_5__.gsap.utils.toArray([
                ".collect__title",
                ".journey"
            ]);
            let maxWidth = 0;
            sections.forEach((section)=>{
                maxWidth += section.offsetWidth;
            });
            console.log(window.innerWidth / 2);
            // scroll animation
            gsap_dist_gsap__WEBPACK_IMPORTED_MODULE_5__.gsap.to("#collect", {
                x: ()=>`-${maxWidth - window.innerWidth / 1.7}`,
                ease: "none",
                scrollTrigger: {
                    trigger: "#collect",
                    start: "left left",
                    end: ()=>`+=${maxWidth}`,
                    scrub: true,
                    pin: true
                }
            });
            // svgs
            gsap_dist_gsap__WEBPACK_IMPORTED_MODULE_5__.gsap.set(".journey-polyline", {
                drawSVG: "0%",
                autoAlpha: 1
            });
            gsap_dist_gsap__WEBPACK_IMPORTED_MODULE_5__.gsap.set(".journey-svg__circle--1", {
                opacity: 0
            });
            gsap_dist_gsap__WEBPACK_IMPORTED_MODULE_5__.gsap.set(".journey-svg__circle-outer--1", {
                opacity: 0
            });
            gsap_dist_gsap__WEBPACK_IMPORTED_MODULE_5__.gsap.set(".journey-svg__circle-outer-dashed--1", {
                opacity: 0,
                transformOrigin: "50% 50%"
            });
            gsap_dist_gsap__WEBPACK_IMPORTED_MODULE_5__.gsap.set(".journey-svg__circle--2", {
                opacity: 0
            });
            gsap_dist_gsap__WEBPACK_IMPORTED_MODULE_5__.gsap.set(".journey-svg__circle-outer--2", {
                opacity: 0
            });
            gsap_dist_gsap__WEBPACK_IMPORTED_MODULE_5__.gsap.set(".journey-svg__circle-outer-dashed--2", {
                opacity: 0,
                transformOrigin: "50% 50%"
            });
            gsap_dist_gsap__WEBPACK_IMPORTED_MODULE_5__.gsap.set(".journey-svg__circle--3", {
                opacity: 0
            });
            gsap_dist_gsap__WEBPACK_IMPORTED_MODULE_5__.gsap.set(".journey-svg__circle-outer--3", {
                opacity: 0
            });
            gsap_dist_gsap__WEBPACK_IMPORTED_MODULE_5__.gsap.set(".journey-svg__circle-outer-dashed--3", {
                opacity: 0,
                transformOrigin: "50% 50%"
            });
            // sections
            gsap_dist_gsap__WEBPACK_IMPORTED_MODULE_5__.gsap.set(".play-to-earn", {
                opacity: 0
            });
            gsap_dist_gsap__WEBPACK_IMPORTED_MODULE_5__.gsap.set(".trade", {
                opacity: 0
            });
            // draw svg desktop animation
            var journeyPolyline = gsap_dist_gsap__WEBPACK_IMPORTED_MODULE_5__.gsap.timeline({
                scrollTrigger: {
                    trigger: ".journey-polyline",
                    start: "top 20%",
                    endTrigger: ".booster-packs",
                    end: "top bottom",
                    scrub: 1
                }
            }).addLabel("one").to(".journey-svg__circle--1", {
                opacity: 1,
                duration: .25
            }, "one").to(".journey-svg__circle-outer--1", {
                opacity: 1,
                duration: .5
            }, "one").to(".journey-svg__circle-outer-dashed--1", {
                opacity: 1,
                rotation: 90,
                duration: .75
            }, "one").to(".journey-polyline", {
                drawSVG: "25%"
            }, "one").addLabel("two").to(".play-to-earn", {
                opacity: 1,
                duration: 1
            }, "two").to(".journey-svg__circle--2", {
                opacity: 1,
                duration: .25
            }, "two").to(".journey-svg__circle-outer--2", {
                opacity: 1,
                duration: .25
            }, "two").to(".journey-svg__circle-outer-dashed--2", {
                opacity: 1,
                rotation: 90,
                duration: .25
            }, "two").to(".journey-polyline", {
                drawSVG: "50%",
                delay: .25
            }, "two").addLabel("three").to(".trade", {
                opacity: 1,
                duration: 2
            }, "three").to(".journey-svg__circle--3", {
                opacity: 1,
                duration: .25
            }, "three").to(".journey-svg__circle-outer--3", {
                opacity: 1,
                duration: .25
            }, "three").to(".journey-svg__circle-outer-dashed--3", {
                opacity: 1,
                rotation: 90,
                duration: .25
            }, "three").to(".journey-polyline", {
                drawSVG: "100%"
            }, "three");
        }
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "index main",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_3___default()), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                        children: t("title")
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "description",
                        content: "Generated by create next app"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "icon",
                        href: "/favicon.ico"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Header__WEBPACK_IMPORTED_MODULE_11__/* .Header */ .h, {}),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
                id: "hero",
                className: `hero ${(_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_16___default().container)}`,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("video", {
                        className: "hero__video",
                        loop: true,
                        autoPlay: true,
                        muted: true,
                        playsInline: true,
                        preload: "metadata",
                        loading: "eager",
                        height: "500",
                        src: "https://doggychewtreats.com/z.webm"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "hero__content",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                                className: "hero__title",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "title--outline hero__title--special",
                                        children: t("home:hero.title-special")
                                    }),
                                    t("home:hero.title")
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "hero__paragraph",
                                children: t("home:hero.paragraph")
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: "button hero__button",
                                children: t("home:hero.button")
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                className: "hero__warning",
                                children: [
                                    t("home:hero.warning"),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                        href: "",
                                        className: "hero-warning__link",
                                        children: [
                                            "(",
                                            t("home:hero.warning-link"),
                                            ")"
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                id: "artists-slider",
                className: `artists-slider`,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_home_SliderArtistsSlick__WEBPACK_IMPORTED_MODULE_9__/* .SliderArtistsSlick */ .G, {})
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
                id: "collect",
                className: `collect ${(_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_16___default().container)}`,
                ref: containerRef,
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                        className: "collect__title",
                        ref: collectTitleRef,
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "collect__title--tiny",
                                children: [
                                    t("home:collect.title-tiny-1"),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                    t("home:collect.title-tiny-2")
                                ]
                            }),
                            t("home:collect.title-1"),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                            t("home:collect.title-2"),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "title--outline",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                    t("home:collect.title-outline")
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        id: "journey",
                        className: `journey`,
                        ref: journeyRef,
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "journey-collect journey__item",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                        className: "journey-collect__title",
                                        children: t("home:collect.journey.collect.title")
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "journey-collect__paragraph",
                                        children: t("home:collect.journey.collect.paragraph")
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        className: "button journey-collect__button",
                                        children: t("home:collect.journey.collect.button")
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "play-to-earn journey__item",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                        className: "play-to-earn__title",
                                        children: t("home:collect.journey.play-to-earn.title")
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "play-to-earn__paragraph",
                                        children: t("home:collect.journey.play-to-earn.paragraph")
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "trade journey__item",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                        className: "trade__title",
                                        children: t("home:collect.journey.trade.title")
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "trade__paragraph",
                                        children: t("home:collect.journey.trade.paragraph")
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "journey-svg__wrapper",
                                ref: journeyWrapperRef,
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "journey-svg__container",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                                            xmlns: "http://www.w3.org/2000/svg",
                                            version: "1.1",
                                            viewBox: "0 0 100 200",
                                            className: "journey-svg--copy",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                                                    className: "journey-svg__circle--1--copy",
                                                    cx: "11",
                                                    cy: "40",
                                                    r: ".75",
                                                    fill: "#595959"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                                                    className: "journey-svg__circle--2--copy",
                                                    cx: "45",
                                                    cy: "25",
                                                    r: ".75",
                                                    fill: "#595959"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                                                    className: "journey-svg__circle--3--copy",
                                                    cx: "90",
                                                    cy: "40",
                                                    r: ".75",
                                                    fill: "#595959"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("polyline", {
                                                    className: "journey-polyline--copy",
                                                    points: "11,40 45,25 90,40",
                                                    fill: "none",
                                                    stroke: "#595959",
                                                    strokeMiterlimit: "10"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                                            xmlns: "http://www.w3.org/2000/svg",
                                            version: "1.1",
                                            viewBox: "0 0 100 200",
                                            className: "journey-svg",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                                                    className: "journey-svg__circle--1",
                                                    cx: "11",
                                                    cy: "40",
                                                    r: ".75",
                                                    fill: "white"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                                                    className: "journey-svg__circle-outer--1",
                                                    cx: "11",
                                                    cy: "40",
                                                    r: "1.5",
                                                    fill: "none",
                                                    stroke: "white",
                                                    strokeWidth: ".15"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                                                    className: "journey-svg__circle-outer-dashed--1",
                                                    cx: "11",
                                                    cy: "40",
                                                    r: "1.9",
                                                    fill: "none",
                                                    stroke: "white",
                                                    strokeWidth: ".15",
                                                    strokeDasharray: ".75,.75"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                                                    className: "journey-svg__circle--2",
                                                    cx: "45",
                                                    cy: "25",
                                                    r: ".75",
                                                    fill: "white"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                                                    className: "journey-svg__circle-outer--2",
                                                    cx: "45",
                                                    cy: "25",
                                                    r: "1.5",
                                                    fill: "none",
                                                    stroke: "white",
                                                    strokeWidth: ".15"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                                                    className: "journey-svg__circle-outer-dashed--2",
                                                    cx: "45",
                                                    cy: "25",
                                                    r: "1.9",
                                                    fill: "none",
                                                    stroke: "white",
                                                    strokeWidth: ".15",
                                                    strokeDasharray: ".75,.75"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                                                    className: "journey-svg__circle--3",
                                                    cx: "90",
                                                    cy: "40",
                                                    r: ".75",
                                                    fill: "white"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                                                    className: "journey-svg__circle-outer--3",
                                                    cx: "90",
                                                    cy: "40",
                                                    r: "1.5",
                                                    fill: "none",
                                                    stroke: "white",
                                                    strokeWidth: ".15"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                                                    className: "journey-svg__circle-outer-dashed--3",
                                                    cx: "90",
                                                    cy: "40",
                                                    r: "1.9",
                                                    fill: "none",
                                                    stroke: "white",
                                                    strokeWidth: ".15",
                                                    strokeDasharray: ".75,.75"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("polyline", {
                                                    className: "journey-polyline",
                                                    points: "11,40 45,25 90,40",
                                                    fill: "none",
                                                    stroke: "white",
                                                    strokeMiterlimit: "10"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                                            xmlns: "http://www.w3.org/2000/svg",
                                            version: "1.1",
                                            viewBox: "0 0 100 200",
                                            className: "journey-svg--mobile--copy",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                                                    className: "journey-svg-mobile__circle--1--copy",
                                                    cx: "5",
                                                    cy: "20",
                                                    r: "3",
                                                    fill: "#595959"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                                                    className: "journey-svg-mobile__circle--2--copy",
                                                    cx: "90",
                                                    cy: "100",
                                                    r: "3",
                                                    fill: "#595959"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                                                    className: "journey-svg-mobile__circle--3--copy",
                                                    cx: "30",
                                                    cy: "180",
                                                    r: "3",
                                                    fill: "#595959"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("polyline", {
                                                    className: "journey-polyline--mobile--copy",
                                                    points: "5,20 90,100 30,180",
                                                    fill: "none",
                                                    stroke: "#595959",
                                                    strokeMiterlimit: "10"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                                            xmlns: "http://www.w3.org/2000/svg",
                                            version: "1.1",
                                            viewBox: "0 0 100 200",
                                            className: "journey-svg--mobile",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                                                    className: "journey-svg-mobile__circle--1",
                                                    cx: "5",
                                                    cy: "20",
                                                    r: "3",
                                                    fill: "white"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                                                    className: "journey-svg-mobile__circle-outer-dashed--1",
                                                    cx: "5",
                                                    cy: "20",
                                                    r: "4.5",
                                                    fill: "none",
                                                    stroke: "white",
                                                    strokeWidth: ".5"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                                                    className: "journey-svg-mobile__circle-outer-dashed--1",
                                                    cx: "5",
                                                    cy: "20",
                                                    r: "5.5",
                                                    fill: "none",
                                                    stroke: "white",
                                                    strokeWidth: ".5",
                                                    strokeDasharray: ".75,.75"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                                                    className: "journey-svg-mobile__circle--2",
                                                    cx: "90",
                                                    cy: "100",
                                                    r: "3",
                                                    fill: "white"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                                                    className: "journey-svg-mobile__circle-outer-dashed--2",
                                                    cx: "90",
                                                    cy: "100",
                                                    r: "4.5",
                                                    fill: "none",
                                                    stroke: "white",
                                                    strokeWidth: ".5"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                                                    className: "journey-svg-mobile__circle-outer-dashed--2",
                                                    cx: "90",
                                                    cy: "100",
                                                    r: "5.5",
                                                    fill: "none",
                                                    stroke: "white",
                                                    strokeWidth: ".5",
                                                    strokeDasharray: ".75,.75"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                                                    className: "journey-svg-mobile__circle--3",
                                                    cx: "30",
                                                    cy: "180",
                                                    r: "3",
                                                    fill: "white"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                                                    className: "journey-svg-mobile__circle-outer-dashed--3",
                                                    cx: "30",
                                                    cy: "180",
                                                    r: "4.5",
                                                    fill: "none",
                                                    stroke: "white",
                                                    strokeWidth: ".5"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                                                    className: "journey-svg-mobile__circle-outer-dashed--3",
                                                    cx: "30",
                                                    cy: "180",
                                                    r: "5.5",
                                                    fill: "none",
                                                    stroke: "white",
                                                    strokeWidth: ".5",
                                                    strokeDasharray: ".75,.75"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("polyline", {
                                                    className: "journey-polyline--mobile",
                                                    points: "5,20 90,100 30,180",
                                                    fill: "none",
                                                    stroke: "white",
                                                    strokeMiterlimit: "10"
                                                })
                                            ]
                                        })
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "abstract-shapes__wrapper",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "abstract-shapes-image__wrapper abstract-shapes-image__wrapper--top",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_15___default()), {
                                    className: "abstract-shapes abstract-shapes--top",
                                    src: "/svgs/abstract-shapes--bottom.svg",
                                    alt: "",
                                    width: "1000",
                                    height: "1000"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "abstract-shapes-image__wrapper abstract-shapes-image__wrapper--bottom",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_15___default()), {
                                    className: "abstract-shapes abstract-shapes--bottom",
                                    src: "/svgs/abstract-shapes.svg",
                                    alt: "",
                                    width: "1000",
                                    height: "1000"
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
                id: "booster-packs",
                className: `booster-packs ${(_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_16___default().container)}`,
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "booster-packs__header",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                className: "booster-packs__title",
                                children: t("home:booster-packs.title")
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "booster-packs__paragraph",
                                children: t("home:booster-packs.paragraph")
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_home_BoosterPacksList__WEBPACK_IMPORTED_MODULE_12__/* .BoosterPacksList */ .r, {})
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
                id: "partnerships",
                className: `partnerships ${(_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_16___default().container)}`,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        className: "partnerships__title",
                        children: t("home:partnerships.title")
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                        className: "partnerships__list",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                className: "partnerships__item",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_15___default()), {
                                    src: "/svgs/polygon-logo.svg",
                                    height: "100%",
                                    width: "100%",
                                    alt: ""
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                className: "partnerships__item",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_15___default()), {
                                    src: "/svgs/animocabrands-logo.svg",
                                    height: "100%",
                                    width: "100%",
                                    alt: ""
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                className: "partnerships__item",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_15___default()), {
                                    src: "/svgs/kingsway-logo.svg",
                                    height: "100%",
                                    width: "100%",
                                    alt: ""
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "blurred-background"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
                id: "latest-news",
                className: `latest-news`,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        className: "latest-news__main-title",
                        children: t("home:latest-news.title")
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_home_LatestNews__WEBPACK_IMPORTED_MODULE_13__/* .LatestNews */ .A, {})
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
                id: "faq",
                className: `faq ${(_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_16___default().container)}`,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        className: "faq__title",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "title--outline",
                            children: "FAQ"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                        className: "faq__list",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                className: "faq__item",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("details", {
                                    open: true,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("summary", {
                                            children: t("home:faqs.faq-1.question")
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            children: t("home:faqs.faq-1.answer")
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                className: "faq__item",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("details", {
                                    open: true,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("summary", {
                                            children: t("home:faqs.faq-2.question")
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            children: t("home:faqs.faq-2.answer")
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                className: "faq__item",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("details", {
                                    open: true,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("summary", {
                                            children: t("home:faqs.faq-3.question")
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            children: t("home:faqs.faq-3.answer")
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                className: "faq__item",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("details", {
                                    open: true,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("summary", {
                                            children: t("home:faqs.faq-4.question")
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            children: t("home:faqs.faq-4.answer")
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
                id: "featured-in",
                className: `featured-in ${(_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_16___default().container)}`,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        className: "featured-in__title",
                        children: t("home:featured-in.title")
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                            className: "featured-in__list",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    className: "featured-in__item",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_15___default()), {
                                        src: "/svgs/deutschrap-plus-logo.svg",
                                        alt: "",
                                        width: "250px",
                                        height: "100%"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    className: "featured-in__item",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_15___default()), {
                                        src: "/svgs/deutsche-startup-logo.svg",
                                        alt: "",
                                        width: "240px",
                                        height: "100%"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    className: "featured-in__item",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_15___default()), {
                                        src: "/svgs/hiphop-de-logo.svg",
                                        alt: "",
                                        width: "240px",
                                        height: "100%"
                                    })
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                id: "buy-now",
                className: `buy-now ${(_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_16___default().container)}`,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                    className: "button",
                    children: t("home:buy-now.button")
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                id: "social-networks",
                className: `social-networks ${(_styles_Home_module_css__WEBPACK_IMPORTED_MODULE_16___default().container)}`
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Footer__WEBPACK_IMPORTED_MODULE_10__/* .Footer */ .$, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "blurred-background"
            })
        ]
    });
};
const getStaticProps = (0,_lib_getStatic__WEBPACK_IMPORTED_MODULE_2__/* .makeStaticProps */ .pc)([
    "common",
    "home",
    "footer"
]);


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9258:
/***/ ((module) => {

"use strict";
module.exports = require("gsap/dist/DrawSVGPlugin");

/***/ }),

/***/ 4965:
/***/ ((module) => {

"use strict";
module.exports = require("gsap/dist/ScrollTrigger");

/***/ }),

/***/ 8472:
/***/ ((module) => {

"use strict";
module.exports = require("gsap/dist/gsap");

/***/ }),

/***/ 1377:
/***/ ((module) => {

"use strict";
module.exports = require("next-i18next");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 3707:
/***/ ((module) => {

"use strict";
module.exports = import("next-language-detector");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [952,61], () => (__webpack_exec__(8869)));
module.exports = __webpack_exports__;

})();